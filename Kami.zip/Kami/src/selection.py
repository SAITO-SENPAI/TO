from color.color import *



def sl():
  print(f"""
{r}[{g}1{r}] {y}Run Tool
{r}[{g}2{r}] {y}Info
{r}[{g}3{r}] {y}Exit
{r}[{g}4{r}] {y}Countdown
{r}[{g}5{r}] {y}Open URL
{r}[{g}6{r}] {y}Time is
  """)