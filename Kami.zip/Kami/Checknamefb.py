import os, sys, re, json
import requests





Token_fb=input(" Nhập Token_Facebook : ")
check_token = json.loads(requests.get('https://graph.facebook.com/me/?access_token='+Token_fb).text)
if "id" in check_token:
        idfb = check_token['id']
        namefb = check_token['name']
        
        
        
print("Name FB: " + str(namefb))  
print("Id FB: " + str(idfb))